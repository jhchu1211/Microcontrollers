void Do_Beep();
void Wait_One_Sec();
void Activate_Buzzer();
void Deactivate_Buzzer();
void Wait_Half_Sec();
